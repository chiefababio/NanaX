from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from uuid import uuid4

router = APIRouter()

class Incident(BaseModel):
    id: str = None
    title: str
    description: str
    location: str
    date: str

incidents = []

@router.post("/")
def create_incident(incident: Incident):
    incident.id = str(uuid4())
    incidents.append(incident)
    return {"message": "Incident reported", "incident": incident}

@router.get("/", response_model=List[Incident])
def list_incidents():
    return incidents

@router.get("/{incident_id}")
def get_incident(incident_id: str):
    for incident in incidents:
        if incident.id == incident_id:
            return incident
    raise HTTPException(status_code=404, detail="Incident not found")
