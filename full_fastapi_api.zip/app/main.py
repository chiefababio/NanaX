from fastapi import FastAPI
from app.routes import incident

app = FastAPI()

app.include_router(incident.router, prefix="/api/incidents", tags=["Incidents"])
